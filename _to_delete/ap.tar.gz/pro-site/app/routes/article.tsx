import type { LinksFunction, LoaderFunctionArgs, MetaFunction } from "react-router";
import { Link, data, useLoaderData } from "react-router";
import articleStyles from "../styles/articles.css?url";
import chromeStyles from "../styles/chrome.css?url";
import { Announcement, SiteFooter, SiteHeader, StructuredData } from "../components/shared/SiteChrome";
import { getPublishedArticle, getPublishedArticles } from "../lib/articles.server";
import { recordArticleView } from "../lib/article-view.server";
import { ORG_ID, PERSON_ID, brandEntities } from "../lib/entity";
import { PRODUCT_PATH, SITE_URL } from "../lib/site";

export const links: LinksFunction = () => [
  { rel: "stylesheet", href: articleStyles },
  { rel: "stylesheet", href: chromeStyles },
];

export async function loader({ params, request }: LoaderFunctionArgs) {
  const article = await getPublishedArticle(params.slug ?? "");
  if (!article) throw new Response("Article not found", { status: 404 });

  recordArticleView(request, article.slug);

  // Newest first, so the "previous" article is the one published after this
  // one. Related prefers the same category and falls back to recency.
  const all = await getPublishedArticles(100);
  const index = all.findIndex((item: any) => item.slug === article.slug);
  const newer = index > 0 ? all[index - 1] : null;
  const older = index >= 0 && index < all.length - 1 ? all[index + 1] : null;
  const sameCategory = all.filter(
    (item: any) => item.slug !== article.slug && item.category?.slug && item.category.slug === article.category?.slug,
  );
  const related = [...sameCategory, ...all.filter((item: any) => item.slug !== article.slug && !sameCategory.includes(item))].slice(0, 3);

  return data(
    { article, newer, older, related },
    { headers: { "Cache-Control": "public, s-maxage=300, stale-while-revalidate=86400" } },
  );
}

export const meta: MetaFunction<typeof loader> = ({ data: loaderData }) => {
  if (!loaderData?.article) return [{ title: "Article not found | Jimmy Coco" }, { name: "robots", content: "noindex" }];
  const article: any = loaderData.article;
  const canonical = `${SITE_URL}/articles/${article.slug}`;
  const title = article.seo_title || `${article.title} | Sunless by Jimmy Coco`;
  const description = article.meta_description || article.excerpt || "";
  return [
    { title }, { name: "description", content: description },
    { name: "robots", content: article.noindex ? "noindex, nofollow" : "index, follow, max-image-preview:large" },
    { property: "og:type", content: "article" }, { property: "og:title", content: article.og_title || title },
    { property: "og:description", content: article.og_description || description }, { property: "og:url", content: canonical },
    ...(article.cover_url ? [{ property: "og:image", content: article.cover_url }] : []),
    { name: "twitter:card", content: "summary_large_image" },
    { tagName: "link", rel: "canonical", href: canonical },
    { tagName: "link", rel: "alternate", hrefLang: "en-GB", href: canonical },
    { tagName: "link", rel: "alternate", hrefLang: "x-default", href: canonical },
  ];
};

const formatDate = (value: string) =>
  new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric" }).format(new Date(value));

/** The brand byline is the organisation, not a person. */
const BRAND_AUTHORS = ["Sunless by Jimmy Coco Trade Team", "Sunless by Jimmy Coco"];

export default function ArticlePage() {
  const { article, newer, older, related }: any = useLoaderData<typeof loader>();
  const canonical = `${SITE_URL}/articles/${article.slug}`;
  const authorName: string = article.author?.name || "Jimmy Coco";
  const isBrand = BRAND_AUTHORS.includes(authorName);

  const schema = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: article.title,
    description: article.meta_description || article.excerpt,
    image: article.cover_url ? [article.cover_url] : undefined,
    datePublished: article.published_at,
    dateModified: article.updated_at,
    author: isBrand
      ? { "@id": ORG_ID }
      : authorName === "Jimmy Coco"
        ? { "@id": PERSON_ID }
        : { "@type": "Person", name: authorName },
    publisher: { "@id": ORG_ID },
    mainEntityOfPage: canonical,
    keywords: article.keywords?.join(", "),
    wordCount: article.content_html ? article.content_html.replace(/<[^>]+>/g, " ").split(/\s+/).filter(Boolean).length : undefined,
  };

  const faq = article.faq_items?.length
    ? {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        mainEntity: article.faq_items.map((item: any) => ({
          "@type": "Question",
          name: item.question,
          acceptedAnswer: { "@type": "Answer", text: item.answer },
        })),
      }
    : null;

  const breadcrumbs = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Professional", item: SITE_URL },
      { "@type": "ListItem", position: 2, name: "Journal", item: `${SITE_URL}/articles` },
      { "@type": "ListItem", position: 3, name: article.title, item: canonical },
    ],
  };

  return (
    <div className="content-shell">
      <StructuredData data={[...brandEntities, schema, breadcrumbs, ...(faq ? [faq] : [])]} />
      <Announcement />
      <SiteHeader page="content" />

      <main className="article-page">
        <nav className="article-nav" aria-label="Article navigation">
          <div>
            {older ? (
              <Link to={`/articles/${older.slug}`}>
                <span>← Previous</span>
                <b>{older.title}</b>
              </Link>
            ) : <span className="article-nav-empty" />}
          </div>
          <Link className="article-nav-all" to="/articles">All articles</Link>
          <div className="article-nav-next">
            {newer ? (
              <Link to={`/articles/${newer.slug}`}>
                <span>Next →</span>
                <b>{newer.title}</b>
              </Link>
            ) : <span className="article-nav-empty" />}
          </div>
        </nav>

        <article>
          {article.cover_url ? (
            <figure className="article-cover">
              <img src={article.cover_url} alt={article.cover?.alt_text || ""} width={1100} height={620} />
            </figure>
          ) : null}

          <header className="article-hero">
            <p className="article-kicker">
              {article.category?.name ? <span className="article-tag">{article.category.name}</span> : null}
              {article.published_at ? <span>{formatDate(article.published_at)}</span> : null}
              <span>{article.reading_time_minutes || 5} min read</span>
            </p>
            <h1>{article.title}</h1>
            {article.excerpt ? <p className="article-standfirst">{article.excerpt}</p> : null}

            <div className="article-byline">
              <span className="article-byline-mark" aria-hidden="true">{isBrand ? "JC" : authorName.slice(0, 1)}</span>
              <span>
                <b>By {authorName}</b>
                {article.author?.job_title ? <small>{article.author.job_title}</small> : null}
                {article.author?.bio ? <small>{article.author.bio}</small> : null}
              </span>
            </div>
          </header>

          <div className="article-body" dangerouslySetInnerHTML={{ __html: article.content_html }} />

          {article.faq_items?.length ? (
            <section className="article-faq" aria-labelledby="faq-title">
              <h2 id="faq-title">Frequently asked questions</h2>
              {article.faq_items.map((item: any, index: number) => (
                <details key={index} name="article-faq">
                  <summary>{item.question}</summary>
                  <p>{item.answer}</p>
                </details>
              ))}
            </section>
          ) : null}

          {article.citations?.length ? (
            <aside className="article-sources">
              <h2>Sources</h2>
              <p className="article-sources-note">Every figure in this article traces to one of these.</p>
              <ol>
                {article.citations.map((citation: any, index: number) => (
                  <li key={index}>
                    {citation.url ? <a href={citation.url} rel="noreferrer nofollow" target="_blank">{citation.text}</a> : citation.text}
                  </li>
                ))}
              </ol>
            </aside>
          ) : null}
        </article>

        {related.length ? (
          <section className="article-related" aria-labelledby="related-title">
            <h2 id="related-title">Keep reading</h2>
            <div className="article-related-grid">
              {related.map((item: any) => (
                <article className="article-card" key={item.id}>
                  <Link to={`/articles/${item.slug}`} className="article-card-image">
                    {item.cover_url ? <img src={item.cover_url} alt={item.cover?.alt_text || ""} loading="lazy" /> : <span />}
                  </Link>
                  <div>
                    <p className="article-card-meta">
                      {item.category?.name || "Professional advice"} · {item.reading_time_minutes || 5} min read
                    </p>
                    <h3><Link to={`/articles/${item.slug}`}>{item.title}</Link></h3>
                    <p>{item.excerpt}</p>
                    <Link className="article-read" to={`/articles/${item.slug}`}>Read article →</Link>
                  </div>
                </article>
              ))}
            </div>
          </section>
        ) : null}

        <section className="article-cta">
          <div>
            <p className="article-kicker">Professional trial</p>
            <h2>Judge the colour on a real client.</h2>
            <p>
              A complimentary professional trial — the Sunset litre and Jimmy's shade guide, posted this
              week. No cost, no commitment, and the guide is yours either way.
            </p>
            <div className="article-cta-actions">
              <Link className="btn btn-bronze" to="/#trial">Request a free trial</Link>
              <Link className="btn btn-ghost-light" to={PRODUCT_PATH}>Order the litre — £60</Link>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter page="content" />
    </div>
  );
}
